﻿Imports System.IO

Public Class frmMain
    Private Sub btnAddCSV_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddCSV.Click
        OpenFileDialog.Filter = "File CSV|*.csv"
        OpenFileDialog.Title = "Select a CSV File"

        If OpenFileDialog.ShowDialog() = DialogResult.OK Then
            If OpenFileDialog.FileName <> vbNullString Then
                If File.Exists(OpenFileDialog.FileName) Then
                    lstCSV.Items.Add(OpenFileDialog.FileName)
                End If
            End If
        End If
    End Sub

    Private Sub btnRemoveCSV_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRemoveCSV.Click
        If lstCSV.SelectedItems.Count > 0 Then
            lstCSV.Items.Remove(lstCSV.SelectedItem)
        End If
    End Sub

    Private Sub btnChooseNewCSV_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnChooseNewCSV.Click
        SaveFileDialog.Filter = "File CSV|*.csv"
        SaveFileDialog.Title = "Save CSV File"
        SaveFileDialog.AddExtension = True
        SaveFileDialog.ShowDialog()

        If SaveFileDialog.FileName <> "" Then
            txtOutputCSV.Text = SaveFileDialog.FileName
        End If
    End Sub

    Private Sub btnQuit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnQuit.Click
        End
    End Sub

    Private Sub btnStart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStart.Click
        Dim i As Integer = 0
        progressBar.Value = 0
        progressBar.Maximum = lstCSV.Items.Count
        progressBar.Step = 1
        Try
            For i = 0 To lstCSV.Items.Count - 1
                Dim csvFile As String = lstCSV.Items(i).ToString()
                Dim fileReader() As Byte
                fileReader = My.Computer.FileSystem.ReadAllBytes(csvFile)
                My.Computer.FileSystem.WriteAllBytes(txtOutputCSV.Text, fileReader, True)
                progressBar.Value = progressBar.Value + 1
            Next i
            MessageBox.Show("Done!", My.Application.Info.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information)
            progressBar.Value = 0
        Catch ex As Exception
            MessageBox.Show(ex.Message, My.Application.Info.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnClearList_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClearList.Click
        lstCSV.Items.Clear()
    End Sub

    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        LinkLabel1.LinkVisited = True
        Try
            System.Diagnostics.Process.Start("mailto:romani.alberto@gmail.com?subject=CSV Joiner")
        Catch ex As Exception
            MessageBox.Show(ex.Message, My.Application.Info.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub frmMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Text = My.Application.Info.ProductName
    End Sub
End Class
