﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.lstCSV = New System.Windows.Forms.ListBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.btnAddCSV = New System.Windows.Forms.Button
        Me.btnRemoveCSV = New System.Windows.Forms.Button
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtOutputCSV = New System.Windows.Forms.TextBox
        Me.btnChooseNewCSV = New System.Windows.Forms.Button
        Me.progressBar = New System.Windows.Forms.ProgressBar
        Me.btnStart = New System.Windows.Forms.Button
        Me.btnQuit = New System.Windows.Forms.Button
        Me.OpenFileDialog = New System.Windows.Forms.OpenFileDialog
        Me.SaveFileDialog = New System.Windows.Forms.SaveFileDialog
        Me.btnClearList = New System.Windows.Forms.Button
        Me.Label3 = New System.Windows.Forms.Label
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel
        Me.SuspendLayout()
        '
        'lstCSV
        '
        Me.lstCSV.FormattingEnabled = True
        Me.lstCSV.Location = New System.Drawing.Point(12, 25)
        Me.lstCSV.Name = "lstCSV"
        Me.lstCSV.Size = New System.Drawing.Size(586, 147)
        Me.lstCSV.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(9, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(95, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Choose files to join"
        '
        'btnAddCSV
        '
        Me.btnAddCSV.Location = New System.Drawing.Point(604, 25)
        Me.btnAddCSV.Name = "btnAddCSV"
        Me.btnAddCSV.Size = New System.Drawing.Size(75, 23)
        Me.btnAddCSV.TabIndex = 2
        Me.btnAddCSV.Text = "Add..."
        Me.btnAddCSV.UseVisualStyleBackColor = True
        '
        'btnRemoveCSV
        '
        Me.btnRemoveCSV.Location = New System.Drawing.Point(604, 54)
        Me.btnRemoveCSV.Name = "btnRemoveCSV"
        Me.btnRemoveCSV.Size = New System.Drawing.Size(75, 23)
        Me.btnRemoveCSV.TabIndex = 3
        Me.btnRemoveCSV.Text = "Remove"
        Me.btnRemoveCSV.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 186)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(55, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Output file"
        '
        'txtOutputCSV
        '
        Me.txtOutputCSV.Location = New System.Drawing.Point(15, 202)
        Me.txtOutputCSV.Name = "txtOutputCSV"
        Me.txtOutputCSV.Size = New System.Drawing.Size(583, 20)
        Me.txtOutputCSV.TabIndex = 5
        '
        'btnChooseNewCSV
        '
        Me.btnChooseNewCSV.Location = New System.Drawing.Point(604, 199)
        Me.btnChooseNewCSV.Name = "btnChooseNewCSV"
        Me.btnChooseNewCSV.Size = New System.Drawing.Size(75, 23)
        Me.btnChooseNewCSV.TabIndex = 6
        Me.btnChooseNewCSV.Text = "Choose..."
        Me.btnChooseNewCSV.UseVisualStyleBackColor = True
        '
        'progressBar
        '
        Me.progressBar.Location = New System.Drawing.Point(15, 228)
        Me.progressBar.Name = "progressBar"
        Me.progressBar.Size = New System.Drawing.Size(583, 21)
        Me.progressBar.TabIndex = 7
        '
        'btnStart
        '
        Me.btnStart.Location = New System.Drawing.Point(15, 259)
        Me.btnStart.Name = "btnStart"
        Me.btnStart.Size = New System.Drawing.Size(75, 23)
        Me.btnStart.TabIndex = 8
        Me.btnStart.Text = "Start"
        Me.btnStart.UseVisualStyleBackColor = True
        '
        'btnQuit
        '
        Me.btnQuit.Location = New System.Drawing.Point(523, 255)
        Me.btnQuit.Name = "btnQuit"
        Me.btnQuit.Size = New System.Drawing.Size(75, 23)
        Me.btnQuit.TabIndex = 9
        Me.btnQuit.Text = "Quit"
        Me.btnQuit.UseVisualStyleBackColor = True
        '
        'OpenFileDialog
        '
        Me.OpenFileDialog.FileName = "OpenFileDialog1"
        '
        'btnClearList
        '
        Me.btnClearList.Location = New System.Drawing.Point(604, 83)
        Me.btnClearList.Name = "btnClearList"
        Me.btnClearList.Size = New System.Drawing.Size(75, 23)
        Me.btnClearList.TabIndex = 10
        Me.btnClearList.Text = "Clear list"
        Me.btnClearList.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(384, 289)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(164, 13)
        Me.Label3.TabIndex = 11
        Me.Label3.Text = "CSV File joiner by Alberto Romani"
        '
        'LinkLabel1
        '
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.Location = New System.Drawing.Point(548, 289)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(131, 13)
        Me.LinkLabel1.TabIndex = 12
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "romani.alberto@gmail.com"
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(686, 311)
        Me.Controls.Add(Me.LinkLabel1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.btnClearList)
        Me.Controls.Add(Me.btnQuit)
        Me.Controls.Add(Me.btnStart)
        Me.Controls.Add(Me.progressBar)
        Me.Controls.Add(Me.btnChooseNewCSV)
        Me.Controls.Add(Me.txtOutputCSV)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.btnRemoveCSV)
        Me.Controls.Add(Me.btnAddCSV)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lstCSV)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "frmMain"
        Me.Text = "CSV File Joiner 0.1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lstCSV As System.Windows.Forms.ListBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnAddCSV As System.Windows.Forms.Button
    Friend WithEvents btnRemoveCSV As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtOutputCSV As System.Windows.Forms.TextBox
    Friend WithEvents btnChooseNewCSV As System.Windows.Forms.Button
    Friend WithEvents progressBar As System.Windows.Forms.ProgressBar
    Friend WithEvents btnStart As System.Windows.Forms.Button
    Friend WithEvents btnQuit As System.Windows.Forms.Button
    Friend WithEvents OpenFileDialog As System.Windows.Forms.OpenFileDialog
    Friend WithEvents SaveFileDialog As System.Windows.Forms.SaveFileDialog
    Friend WithEvents btnClearList As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents LinkLabel1 As System.Windows.Forms.LinkLabel

End Class
